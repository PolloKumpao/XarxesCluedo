Reset movimientos-> r

Fijar posicion -> Espacio

El juego solo funciona para el jugador principal y si entran 3 clientes.
